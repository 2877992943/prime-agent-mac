# Prime Agent 在 deepin 虚拟机内的部署笔记

> 环境记录日期: 2026-11-11
> Host: server14 (10.30.33.14, 用户 uos)
> VM: gui-env-vm-1 (deepin 25, 用户 uos, 密码 1), 由 /data/yr/gui_env_new/start_vm.sh 启动

---

## 1. 踩的坑

### 坑 1: SSH 进 VM 不知道密码 / 账号
- VM 用户是 `uos`，密码已改为 `1`（初始密码是 `CSY3liang$`）
- 必须用 `sshpass`（host 上已装: `/usr/bin/sshpass`）

### 坑 2: models.json 的路径 —— 最大的坑
- 网上直觉/文档会以为配置在 `~/.config/prime-agent/models.json` → **错，不生效**，
  `prime-agent model list` 始终报 "No models available. Use /login"
- **正确路径: `~/.prime/agent/models.json`**（即 `$HOME/.prime/agent/`）
- 依据: 官方源码 `crates/pa-types/src/platform/dirs.rs` 中
  `CONFIG_DIR_NAME: &str = ".prime/agent"`，models.json 由
  `ModelRegistry::create(auth, config.agent_dir.join("models.json"))` 加载
- 也可用环境变量 `PRIME_AGENT_CODING_AGENT_DIR` 覆盖整个 agent 目录

### 坑 3: models.json 的格式 —— 必须是 providers 包裹结构
顶层是 `{"providers": {名字: {...}}}`，provider 级必填 `baseUrl` + `apiKey`，
model 级必填 `id`，`api` 在 provider 或 model 级至少一处指定。
直接放一个 `{"models": [...]}` 数组顶层会解析失败（源码 `crates/pa-core/src/models/custom.rs`）。
支持 `//` 注释和尾逗号。

### 坑 4: 安装慢不是卡死
- `curl | sh` 本身很快，主包只有 22MB
- 真正耗时的是安装后首次启动时 uv 给 kernel-venv 装 pandas/numpy/scipy 等
  （~700MB uv 缓存，VM 外网走 libvirt NAT 只有 ~34KB/s，全程约 50 分钟）
- 判断是否还在干活: 看 `~/.cache/uv` 是否还在增长

### 坑 5: glm53flash 是思考(reasoning)模型
- 回复先输出 `reasoning_content`（思考过程），再输出 `content`（最终答案）
- 测试时 `max_tokens` 给太小（如 64）会思考没结束就截断，content 为空，
  看起来像"失败"——实际只是截断。给 256+ 即可
- models.json 里要标 `"reasoning": true`

### 坑 6: pyautogui 在 SSH 会话里要手动指定 DISPLAY
- SSH 进 VM 没有 DISPLAY 环境变量，直接 `import pyautogui` 报 `KeyError: 'DISPLAY'`
- 解决: `DISPLAY=:0 python3 xxx.py`
- VM 内置 Python 3.12 已装 pyautogui 0.9.54、requests 2.32.5（无 openai 包，用 curl/requests 即可）

### 坑 7: `~/.local/bin` 不在 PATH
- 安装完提示 prime-agent 不在 PATH，非登录 shell 找不到命令
- 解决: `echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc`（VM 内已配好）

---

## 2. 如何启动 prime-agent（环境说明）

### 前置环境（VM 内，均已就绪）
| 组件 | 位置 |
|------|------|
| prime-agent 0.10.2 (Rust) | `~/.local/bin/prime-agent`（launcher）/ `~/.local/share/prime-agent/`（本体） |
| kernel venv (Python 3.11 + 39 包) | `~/.prime/agent/kernel-venv` |
| 自定义模型配置 | `~/.prime/agent/models.json` → host sglang |

### 模型配置（已写入 ~/.prime/agent/models.json）
```json
{
  "providers": {
    "host-sglang": {
      "name": "Host sglang (GLM)",
      "api": "openai-completions",
      "baseUrl": "http://192.168.122.1:5919/v1",
      "apiKey": "Tongxin123",
      "models": [
        {
          "id": "glm53flash",
          "name": "GLM 5.3 Flash",
          "reasoning": true,
          "input": ["text", "image"],
          "contextWindow": 1048576,
          "maxTokens": 8192
        }
      ]
    }
  }
}
```

关键点: VM 里访问 host 上的 sglang 用 **`http://192.168.122.1:5919`** ——
这是 libvirt virbr0 NAT 网桥的网关 IP（host 在 VM 内视角），不是 host 的业务 IP。
前提是 sglang 监听 `0.0.0.0:5919`（已确认）。

### 启动方式
```bash
# 一次性问答 (print 模式)
~/.local/bin/prime-agent --provider host-sglang --model glm53flash -p "你的问题"

# 交互式 TUI（进入后可用 /model 切模型）
~/.local/bin/prime-agent --provider host-sglang --model glm53flash

# 查看已配置的模型
~/.local/bin/prime-agent model list
```

注意: VM 重建后（start_vm.sh 每次都从模板全新启动），
**`~/.local/`、`~/.prime/` 里的 prime-agent 安装和配置会全部丢失**，
需要重新执行安装 + 写 models.json。好在 uv 缓存在 `~/.cache/uv` 也一样会丢，重装同样要 ~50 分钟。

---

## 3. 从 host 如何 SSH 到 VM

### 先拿到 VM 的 IP（每次重建都会变）
VM 由 start_vm.sh 启动，走 libvirt default NAT 网络（virbr0, 192.168.122.0/24），
DHCP 动态分配 IP。两种方式查 IP:

```bash
# 方式 A: DHCP 租约（按 MAC 查）
MAC=$(virsh --connect qemu:///system dumpxml gui-env-vm-1 \
      | sed -n "s/.*<mac address='\([0-9a-f:]*\)'.*/\1/p" | head -1)
sudo -n virsh --connect qemu:///system net-dhcp-leases default | grep -i "$MAC"

# 方式 B: arp 表
ip neigh show dev virbr0 | grep -i "$MAC"
```

当前: VM `gui-env-vm-1` 的 MAC 是 `52:54:00:ff:fd:d6`，IP 是 `192.168.122.73`（会变）。

### SSH 命令（在 host server14 上执行）
```bash
sshpass -p '1' ssh -o StrictHostKeyChecking=no uos@192.168.122.73 '命令'
sshpass -p '1' scp -o StrictHostKeyChecking=no 本地文件 uos@192.168.122.73:/tmp/
```

- 用户 `uos`，密码 `1`（root 不可 SSH）
- VM 内跑 GUI 相关脚本（如 pyautogui）记得加 `DISPLAY=:0`

### 从办公电脑进 VM（多级跳）
办公电脑 → jump-uos (100.82.227.55) → server14 (10.30.33.14) → VM:
```bash
ssh 14   # 到 host (办公电脑 ssh config 已配 ProxyJump jump-uos)
sshpass -p '1' ssh uos@192.168.122.73   # 再进 VM
```

---

## 附: 一键测试脚本（已存在）

| 文件 | 位置 | 用途 |
|------|------|------|
| `call_llm_test.py` | host: `/data/yr/gui_env_new/test_in_vm_callLlm/` | VM 内直接 curl 调 host sglang（3 项测试） |
| `run_test.sh` | 同上 | host 上运行: 自动查 VM IP → 推送脚本 → VM 内执行 |
| `pyautogui_test.py` | 同上 | VM 内 pyautogui 鼠标控制测试（7 项，需 DISPLAY=:0） |

运行: 在 host 上 `cd /data/yr/gui_env_new/test_in_vm_callLlm && ./run_test.sh`
