#!/usr/bin/env bash
# 基于模板启动 deepin 虚拟机 (libvirt/virsh)
# 模板保持只读，实际使用 overlay 磁盘(backing file)
#
# 用法:
#   ./start_vm.sh [虚拟机名称]
#   VM_NAME=xxx MEMORY_MB=8192 ./start_vm.sh
#
# 可用环境变量覆盖:
#   MEMORY_MB     内存 MB (默认 12288)
#   VCPUS         vCPU 数 (默认 6)
#   DISK_GB       overlay 磁盘大小 GB (默认 100, 与模板一致)
#   VNC_BASE_PORT VNC 端口起始值 (默认 5920, 被占用时自动向后找空闲端口)
#   VNC_PASSWORD  VNC 密码 (默认 1)
set -euo pipefail

VM_NAME="${1:-${VM_NAME:-gui-env-vm-2}}"
#TEMPLATE_IMAGE="/data/yr/GUI_env/vm_image/deepin-template-1010.qcow2"
TEMPLATE_IMAGE="/data/yr/gui_env_new/deepin-1112-saved.qcow2"
DISK_DIR="/data/yr/gui_env_new/vm_disks"
DISK_PATH="${DISK_DIR}/${VM_NAME}.qcow2"
MEMORY_MB="${MEMORY_MB:-12288}"
VCPUS="${VCPUS:-6}"
DISK_GB="${DISK_GB:-100}"
VNC_BASE_PORT="${VNC_BASE_PORT:-5920}"
VNC_PASSWORD="${VNC_PASSWORD:-1}"
VIRSH="virsh --connect qemu:///system"

log() { echo "[$(date '+%F %T')] $*"; }

# 1. 找一个空闲的 VNC 端口
find_free_port() {
  local port=$VNC_BASE_PORT
  while ss -tln "sport = :$port" | grep -q LISTEN; do
    port=$((port + 1))
  done
  echo "$port"
}

# 2. 清理同名旧虚拟机（每次都从干净模板启动）
if $VIRSH dominfo "$VM_NAME" &>/dev/null; then
  log "销毁已存在的虚拟机 $VM_NAME"
  $VIRSH destroy "$VM_NAME" 2>/dev/null || true
  $VIRSH undefine "$VM_NAME" 2>/dev/null || true
fi
mkdir -p "$DISK_DIR"
rm -f "$DISK_PATH"

# 3. 基于模板创建 overlay 磁盘
log "创建 overlay 磁盘: $DISK_PATH (backing: $TEMPLATE_IMAGE)"
qemu-img create -f qcow2 \
  -o backing_file="$TEMPLATE_IMAGE",backing_fmt=qcow2 \
  "$DISK_PATH" "${DISK_GB}G"

# 4. 定义并启动虚拟机
VNC_PORT=$(find_free_port)
log "启动虚拟机 $VM_NAME (内存 ${MEMORY_MB}MB, vCPU ${VCPUS}, VNC 端口 $VNC_PORT)"
virt-install \
  --connect qemu:///system \
  --name "$VM_NAME" \
  --memory "$MEMORY_MB" \
  --vcpus "$VCPUS" \
  --disk path="$DISK_PATH",format=qcow2,bus=virtio \
  --network bridge=virbr0,model=virtio \
  --graphics vnc,listen=0.0.0.0,port="$VNC_PORT",password="$VNC_PASSWORD" \
  --video virtio \
  --console pty,target_type=serial \
  --import --noautoconsole \
  --osinfo detect=on,require=off \
  --check path_in_use=off

# 5. 等待进入 running 状态
STATE=""
for _ in $(seq 1 60); do
  STATE=$($VIRSH domstate "$VM_NAME" 2>/dev/null || echo "not found")
  [ "$STATE" = "running" ] && break
  sleep 2
done
if [ "$STATE" != "running" ]; then
  log "错误: 虚拟机未进入 running 状态 (当前: $STATE)"
  $VIRSH dominfo "$VM_NAME" 2>/dev/null || true
  exit 1
fi
log "虚拟机 $VM_NAME 已运行"

# 6. 等待客户机获取 DHCP IP（说明系统已启动到网络栈）
MAC=$($VIRSH dumpxml "$VM_NAME" | sed -n "s/.*<mac address='\([0-9a-f:]*\)'.*/\1/p" | head -1)
log "等待客户机联网 (MAC: ${MAC:-unknown}) ..."
IP=""
for _ in $(seq 1 90); do
  if [ -n "$MAC" ]; then
    IP=$(sudo -n virsh --connect qemu:///system net-dhcp-leases default 2>/dev/null \
         | grep -i "$MAC" | awk '{print $5}' | sed 's|/.*||' | head -1) || true
    # 租约里还没有时, 尝试 arp 表
    [ -n "$IP" ] || IP=$(ip neigh show dev virbr0 2>/dev/null \
         | grep -i "$MAC" | awk '{print $1}' | head -1) || true
  fi
  [ -n "$IP" ] && break
  sleep 2
done

echo
echo "===== 虚拟机信息 ====="
echo "  名称:      $VM_NAME"
echo "  磁盘:      $DISK_PATH (backing: $TEMPLATE_IMAGE)"
echo "  VNC:       $(hostname -I | awk '{print $1}'):$VNC_PORT  (密码: $VNC_PASSWORD)"
if [ -n "$IP" ]; then
  echo "  IP:        $IP (已联网)"
else
  echo "  IP:        未获取到 DHCP 租约（系统可能仍在启动中）"
fi
echo "  virsh 控制台: virsh console $VM_NAME / $VIRSH dominfo $VM_NAME"
