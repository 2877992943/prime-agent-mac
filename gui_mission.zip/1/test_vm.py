#!/data/yr/myenv_vm/bin/python
"""测试虚拟机是否正常启动并可用。

使用 uv 环境 /data/yr/myenv_vm 中的 python 运行（内含 libvirt 模块）:
    /data/yr/myenv_vm/bin/python test_vm.py [虚拟机名称]

检查项:
  1. libvirt 连接与虚拟机 running 状态
  2. overlay 磁盘 backing chain 指向模板镜像
  3. VNC 端口可握手 (RFB 协议)
  4. DHCP 租约中获取到客户机 IP
  5. ping 客户机 / SSH(22) 端口连通性 (仅提示, 不算失败)
"""
import socket
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

import libvirt

TEMPLATE_IMAGE = "/data/yr/GUI_env/vm_image/deepin-template-1010.qcow2"


def find_vm_ip(mac):
    """通过 DHCP 租约 / arp 表查找虚拟机 IP"""
    leases = subprocess.run(
        ["sudo", "-n", "virsh", "--connect", "qemu:///system",
         "net-dhcp-leases", "default"],
        capture_output=True, text=True,
    ).stdout
    for line in leases.splitlines():
        if mac and mac.lower() in line.lower():
            # 第5列是 IP/前缀
            parts = line.split()
            if len(parts) >= 5 and "/" in parts[4]:
                return parts[4].split("/")[0]
    neigh = subprocess.run(
        ["ip", "neigh", "show", "dev", "virbr0"],
        capture_output=True, text=True,
    ).stdout
    for line in neigh.splitlines():
        if mac and mac.lower() in line.lower():
            return line.split()[0]
    return None

vm_name = sys.argv[1] if len(sys.argv) > 1 else "gui-env-vm-1"
results = []


def check(name, ok, detail=""):
    tag = "PASS" if ok else "FAIL"
    results.append(ok)
    print(f"[{tag}] {name}" + (f" -- {detail}" if detail else ""))


# 1. libvirt 连接与状态
conn = libvirt.open("qemu:///system")
check("连接 libvirt (qemu:///system)", conn is not None)
try:
    dom = conn.lookupByName(vm_name)
    state, _ = dom.state()
    check("虚拟机 running 状态", state == libvirt.VIR_DOMAIN_RUNNING,
          f"state={dom.state()[0]}")
except libvirt.libvirtError as e:
    check(f"查找虚拟机 {vm_name}", False, str(e))
    print("测试终止")
    sys.exit(1)

xml = ET.fromstring(dom.XMLDesc())

# 2. 磁盘 backing chain
disk_path = None
for source in xml.iter("source"):
    if "file" in source.attrib:
        disk_path = source.attrib["file"]
        break
if disk_path:
    info = subprocess.run(
        ["qemu-img", "info", "-U", "--backing-chain", disk_path],
        capture_output=True, text=True,
    )
    backing_ok = TEMPLATE_IMAGE in info.stdout
    check("overlay 磁盘 backing 指向模板", backing_ok, disk_path)
else:
    check("找到磁盘配置", False)

# 3. VNC 握手
graphics = xml.find("./devices/graphics[@type='vnc']")
vnc_port = int(graphics.get("port")) if graphics is not None else None
if vnc_port and vnc_port > 0:
    try:
        with socket.create_connection(("127.0.0.1", vnc_port), timeout=5) as s:
            banner = s.recv(12)
        check(f"VNC 握手 (端口 {vnc_port})", banner.startswith(b"RFB"),
              f"banner={banner!r}")
    except OSError as e:
        check(f"VNC 握手 (端口 {vnc_port})", False, str(e))
else:
    check("VNC 端口配置", False, f"port={vnc_port}")

# 4. DHCP 租约 -> IP (最多等 3 分钟)
mac_el = xml.find("./devices/interface/mac")
mac = mac_el.get("address") if mac_el is not None else None
ip = None
deadline = time.time() + 180
while time.time() < deadline:
    ip = find_vm_ip(mac)
    if ip:
        break
    time.sleep(5)
check("客户机获取 DHCP IP", ip is not None, f"MAC={mac} IP={ip}")

# 5. ping / SSH (提示性)
if ip:
    ping = subprocess.run(
        ["ping", "-c", "1", "-W", "2", ip],
        capture_output=True,
    )
    check(f"ping {ip}", ping.returncode == 0,
          "不可达(可能被防火墙拦截, 仅提示)" if ping.returncode else "")
    try:
        with socket.create_connection((ip, 22), timeout=5):
            check(f"SSH 端口 {ip}:22", True)
    except OSError as e:
        check(f"SSH 端口 {ip}:22", False, f"{e} (仅提示)")

passed, total = sum(results), len(results)
print(f"\n结果: {passed}/{total} 通过")
sys.exit(0 if passed == total else 1)
