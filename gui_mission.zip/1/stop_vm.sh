#!/usr/bin/env bash
# 停止并清理虚拟机: 销毁、undefine、删除 overlay 磁盘（模板不受影响）
# 用法: ./stop_vm.sh [虚拟机名称]
set -euo pipefail

VM_NAME="${1:-${VM_NAME:-gui-env-vm-1}}"
DISK_PATH="/data/yr/gui_env_new/vm_disks/${VM_NAME}.qcow2"
VIRSH="virsh --connect qemu:///system"

if $VIRSH dominfo "$VM_NAME" &>/dev/null; then
  echo "销毁虚拟机 $VM_NAME ..."
  $VIRSH destroy "$VM_NAME" 2>/dev/null || true
  $VIRSH undefine "$VM_NAME" 2>/dev/null || true
else
  echo "虚拟机 $VM_NAME 不存在"
fi

if [ -f "$DISK_PATH" ]; then
  echo "删除 overlay 磁盘 $DISK_PATH"
  rm -f "$DISK_PATH"
fi
echo "清理完成"
