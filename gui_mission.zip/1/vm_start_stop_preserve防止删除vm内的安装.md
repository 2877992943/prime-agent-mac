# 虚拟机开关机操作说明（保留已有设置）

适用虚拟机：`gui-env-vm-1`

目标：开机、关机、重启时保留虚拟机内已经安装的 prime-agent、gui_mission、cua、Python 环境、模型配置和桌面设置。

## 一、最重要的注意事项

**保留现有虚拟机后，不要再执行以下脚本：**

```bash
/data/yr/gui_env_new/start_vm.sh
/data/yr/gui_env_new/stop_vm.sh
/data/yr/gui_env_new/run_test.sh
```

原因：

- `start_vm.sh` 会销毁并 undefine 现有虚拟机，然后执行 `rm -f` 删除 overlay 磁盘，再从干净模板重建。
- `stop_vm.sh` 会销毁、undefine 虚拟机，并删除 overlay 磁盘。
- `run_test.sh` 会调用 `start_vm.sh`，因此同样会清空已有虚拟机设置。

这些脚本适用于“从干净模板重新创建测试 VM”，不适用于“保留环境后日常开关机”。

## 二、数据保存在哪里

当前系统盘：

```text
/data/yr/gui_env_new/vm_disks/gui-env-vm-1.qcow2
```

它是 overlay 磁盘，模板为：

```text
/data/yr/GUI_env/vm_image/deepin-template-1010.qcow2
```

VM 内的以下修改都写入 overlay 磁盘：

- `~/.local/bin/prime-agent` 和 prime-agent 本体；
- `~/.prime/agent/models.json`；
- `~/.prime/agent/skills/` 下的 gui_mission、cua；
- kernel-venv 和 pyautogui、pillow 等依赖；
- `.bashrc`、桌面设置及其他用户文件。

保留 overlay 磁盘并继续使用它启动，这些数据就会保留。

注意：libvirt 的虚拟机定义（CPU、内存、网卡等）不属于磁盘内容。不要执行 `virsh undefine`，否则即使磁盘保留，虚拟机定义也会丢失。

## 三、查看虚拟机状态

在 host（server14）上执行：

```bash
virsh --connect qemu:///system domstate gui-env-vm-1
```

查看虚拟机当前使用的磁盘：

```bash
virsh --connect qemu:///system domblklist gui-env-vm-1
```

正常应看到：

```text
/data/yr/gui_env_new/vm_disks/gui-env-vm-1.qcow2
```

## 四、开机（保留设置）

直接启动已经定义的虚拟机：

```bash
virsh --connect qemu:///system start gui-env-vm-1
```

确认进入 running：

```bash
virsh --connect qemu:///system domstate gui-env-vm-1
```

**不要再次运行 `start_vm.sh`。**

## 五、关机（保留设置）

优先使用 ACPI 正常关机：

```bash
virsh --connect qemu:///system shutdown gui-env-vm-1
```

等待关机完成：

```bash
for _ in $(seq 1 60); do
  state=$(virsh --connect qemu:///system domstate gui-env-vm-1 2>/dev/null || true)
  echo "$state"
  [ "$state" = "shut off" ] && break
  sleep 2
done
```

正常关机不会删除虚拟机定义和 overlay 磁盘，下次直接 `virsh start` 即可。

### 强制关机（仅在正常关机无效时）

```bash
virsh --connect qemu:///system destroy gui-env-vm-1
```

`destroy` 相当于强制断电，本身不会删除磁盘，但可能造成未保存数据丢失或文件系统损坏。它不是日常关机首选。

## 六、重启（保留设置）

优先尝试：

```bash
virsh --connect qemu:///system reboot gui-env-vm-1
```

如果 `reboot` 不生效，使用正常关机后再启动：

```bash
virsh --connect qemu:///system shutdown gui-env-vm-1
# 等到 domstate 显示 shut off 后：
virsh --connect qemu:///system start gui-env-vm-1
```

## 七、启动后查询 VM IP

VM 使用 libvirt default NAT 网络，重启后 DHCP IP 可能变化。

```bash
MAC=$(virsh --connect qemu:///system dumpxml gui-env-vm-1 \
  | sed -n "s/.*<mac address='\([0-9a-f:]*\)'.*/\1/p" | head -1)

sudo -n virsh --connect qemu:///system net-dhcp-leases default \
  | grep -i "$MAC"
```

也可以查询 ARP 表：

```bash
ip neigh show dev virbr0 | grep -i "$MAC"
```

查到 IP 后，从 host 登录：

```bash
sshpass -p '1' ssh -o StrictHostKeyChecking=no uos@<VM_IP>
```

## 八、日常操作速查

```bash
# 查看状态
virsh --connect qemu:///system domstate gui-env-vm-1

# 保留环境开机
virsh --connect qemu:///system start gui-env-vm-1

# 保留环境正常关机
virsh --connect qemu:///system shutdown gui-env-vm-1

# 保留环境重启
virsh --connect qemu:///system reboot gui-env-vm-1
```

禁止使用以下操作来“重启”现有环境：

```bash
./start_vm.sh       # 会删除磁盘并重建
./stop_vm.sh        # 会删除磁盘
virsh undefine ...  # 会删除 libvirt 虚拟机定义
```
